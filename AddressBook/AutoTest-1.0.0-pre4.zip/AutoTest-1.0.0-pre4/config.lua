local config = {}
config.msbuild = [[C:\Program Files (x86)\Microsoft Visual Studio\2019\Community\MSBuild\Current\Bin\]]
config.javac = [[]]
return config;