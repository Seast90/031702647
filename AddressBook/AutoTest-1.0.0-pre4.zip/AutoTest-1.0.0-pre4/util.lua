function github(name,repo)
    return string.format( "https://github.com/%s/%s.git",name,repo)
end
